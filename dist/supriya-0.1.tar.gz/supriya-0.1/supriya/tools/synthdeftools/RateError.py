# -*- encoding: utf-8 -*-


class RateError(Exception):
    pass
