# -*- encoding: utf-8 -*-
from abjad.tools import datastructuretools


class Enumeration(datastructuretools.Enumeration):
    pass
