# -*- encoding: utf-8 -*-

"""
Tools for working in non-realtime.
"""

from abjad.tools import systemtools

systemtools.ImportManager.import_structured_package(
    __path__[0],
    globals(),
    )
