# -*- encoding: utf-8 -*-
from abjad.tools.commandlinetools.CommandlineScript import CommandlineScript


class ProjectPackageScript(CommandlineScript):

    ### CLASS VARIABLES ###

    __slots__ = ()
