# -*- encoding: utf-8 -*-
from supriya.tools.ugentools.PureUGen import PureUGen


class Select(PureUGen):
    """

    ::

        >>> select = ugentools.Select.ar(
        ...     array=array,
        ...     which=which,
        ...     )
        >>> select
        Select.ar()

    """

    ### CLASS VARIABLES ###

    __documentation_section__ = None

    __slots__ = ()

    _ordered_input_names = (
        'which',
        'array',
        )

    _valid_calculation_rates = None

    ### INITIALIZER ###

    def __init__(
        self,
        calculation_rate=None,
        array=None,
        which=None,
        ):
        PureUGen.__init__(
            self,
            calculation_rate=calculation_rate,
            array=array,
            which=which,
            )

    ### PUBLIC METHODS ###

    @classmethod
    def ar(
        cls,
        array=None,
        which=None,
        ):
        """
        Constructs an audio-rate Select.

        ::

            >>> select = ugentools.Select.ar(
            ...     array=array,
            ...     which=which,
            ...     )
            >>> select
            Select.ar()

        Returns ugen graph.
        """
        from supriya.tools import synthdeftools
        calculation_rate = synthdeftools.CalculationRate.AUDIO
        ugen = cls._new_expanded(
            calculation_rate=calculation_rate,
            array=array,
            which=which,
            )
        return ugen

    @classmethod
    def kr(
        cls,
        array=None,
        which=None,
        ):
        """
        Constructs a control-rate Select.

        ::

            >>> select = ugentools.Select.kr(
            ...     array=array,
            ...     which=which,
            ...     )
            >>> select
            Select.kr()

        Returns ugen graph.
        """
        from supriya.tools import synthdeftools
        calculation_rate = synthdeftools.CalculationRate.CONTROL
        ugen = cls._new_expanded(
            calculation_rate=calculation_rate,
            array=array,
            which=which,
            )
        return ugen

    ### PUBLIC PROPERTIES ###

    @property
    def array(self):
        """
        Gets `array` input of Select.

        ::

            >>> select = ugentools.Select.ar(
            ...     array=array,
            ...     which=which,
            ...     )
            >>> select.array

        Returns ugen input.
        """
        index = self._ordered_input_names.index('array')
        return self._inputs[index]

    @property
    def which(self):
        """
        Gets `which` input of Select.

        ::

            >>> select = ugentools.Select.ar(
            ...     array=array,
            ...     which=which,
            ...     )
            >>> select.which

        Returns ugen input.
        """
        index = self._ordered_input_names.index('which')
        return self._inputs[index]
