# -*- encoding: utf-8 -*-


class NotAllocatedError(Exception):
    pass
