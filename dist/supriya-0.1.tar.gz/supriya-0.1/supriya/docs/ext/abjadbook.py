def setup(app):
    from abjad.tools import abjadbooktools
    abjadbooktools.SphinxDocumentHandler.setup_sphinx_extension(app)
